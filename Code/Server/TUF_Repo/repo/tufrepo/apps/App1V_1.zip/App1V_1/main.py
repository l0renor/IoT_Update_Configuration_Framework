# import the standard JSON parser
import json
import subprocess
import time
from time import strptime

import datetime
import requests

# import the REST library
last_changed = datetime.datetime.now()
BASE_URL = "http://0.0.0.0:8000/rest/devices/"
CONFIG_FILE = 'config.json'


def run(path, device, user, password):
    while 1:
        loadConfig(path, device, user, password)  # via http rest
        time.sleep(20)


def loadConfig(path, device, user, password):
    print("starting dowload")
    resp = requests.get(BASE_URL + str(device), auth=(user, password))
    print(resp.json())
    # datetime_str = resp.json()['last_changed']

    # changed = strptime(datetime_str, '%Y-%m-%dT%H:%M:%S.%fZ')
    # changed = datetime.datetime.fromtimestamp(time.mktime(changed))
    # global last_changed

    if 1:  # changed < last_changed:
        print('newer config found')
        # last_changed = datetime.datetime.now()
        with open(CONFIG_FILE, 'w') as outfile:
            json.dump(resp.json()['iptables-device:device']['ip_rule_set'], outfile)
        print("finished download now execute")
    create_config(path)
    execute_conf(path)


def create_config(path):
    with open('config.json') as json_file:
        data = json.load(json_file)
        with open(path + 'script.sh', 'w') as outfile:
            outfile.write('#!/bin/sh\n')
            outfile.write('echo \"firewall script running\"\n')
            outfile.write('iptables -F\n')
            outfile.write('iptables -X\n')
            for date in data:
                command = "iptables -A {} ".format(date['chain'])

                if len(date['packet_type']) != "all":
                    command += "-p {} ".format(date['packet_type'])

                if date['destination_port'] > 0:
                    command += "--dport {} ".format(date['destination_port'])
                command += "-j {}\n".format(date['action'])
                outfile.write(command)
                #TODO  bash(commad) here?

def _bash(cmd: str) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, shell=True, check=True, executable="/bin/bash")


def execute_conf(path):
    _bash('pwd')
    _bash('sudo chmod -v 700 {}script.sh'.format(path))
    _bash('sudo ./{}script.sh'.format(path))


if __name__ == "__main__":
    run()
