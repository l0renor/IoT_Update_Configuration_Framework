#!/bin/sh
echo "firewall script running"
iptables -F
iptables -X
iptables -A INPUT -p tcp --dport 4 -j ACCEPT
iptables -A INPUT -p tcp -j ACCEPT
